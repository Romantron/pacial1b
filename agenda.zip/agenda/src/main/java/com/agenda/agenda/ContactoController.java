package com.agenda.agenda;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@RestController
@RequestMapping("/api/contactos") // Endpoint base
@CrossOrigin("*") // Permite llamadas desde cualquier dominio (útil para frontend separado)
public class ContactoController {

    private List<Contacto> contactos = new CopyOnWriteArrayList<>();

    // Obtener todos los contactos
    @GetMapping
    public ResponseEntity<List<Contacto>> getContactos() {
        return ResponseEntity.ok(contactos);
    }

    // Agregar un nuevo contacto
    @PostMapping
    public ResponseEntity<String> addContacto(@RequestBody Contacto contacto) {
        if (contacto.getNombre() == null || contacto.getNombre().trim().isEmpty()) {
            return ResponseEntity.badRequest().body("El nombre no puede ser nulo o vacío.");
        }

        for (Contacto c : contactos) {
            if (c.getNombre().equalsIgnoreCase(contacto.getNombre())) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body("El contacto ya existe.");
            }
        }

        contactos.add(contacto);
        return ResponseEntity.status(HttpStatus.CREATED).body("Contacto agregado: " + contacto.getNombre());
    }

 // Eliminar un contacto por nombre
    @DeleteMapping("/{nombre}")
    public String deleteContacto(@PathVariable String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return "Nombre inválido.";
        }

        boolean removed = contactos.removeIf(c -> c.getNombre().equalsIgnoreCase(nombre));

        if (removed) {
            return "Contacto eliminado: " + nombre;
        } else {
            return "Contacto no encontrado.";
        }
    }

    // Limpiar la lista de contactos
    @DeleteMapping("/limpiar")
    public ResponseEntity<String> limpiarContactos() {
        contactos.clear();
        return ResponseEntity.ok("Todos los contactos han sido eliminados.");
    }
}
